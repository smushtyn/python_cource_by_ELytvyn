from pyparsing import *


test = """
Traceback (most recent call last):
    File "/home/lytvyn/python_course/lesson16/lesson16.py", line 8, in <module>
    ZeroDivisionError: integer division or modulo by zero
"""

trace_string = """
Traceback (most recent call last):
  File "/home/lytvyn/python_course/lesson16/lesson16.py", line 8, in <module>
    a()
  File "/home/lytvyn/python_course/lesson16/lesson16.py", line 7, in a
    5/0
ZeroDivisionError: integer division or modulo by zero
"""


def trace_parse(token):
    print token


trace = Keyword('Traceback')
# trace = Keyword('Traceback').suppress()  # suppress - found match will be not passed to token / not get to the output / skipped
empty_line = lineStart + SkipTo(lineEnd)
COLON = Literal(':').suppress()
COMMA = Literal(',')
start_trace = trace + SkipTo(COLON).suppress() + COLON
line = Keyword('line')
dig = Word(nums)  # nums -> 0 - 9
module = Word('.<>' + alphanums)
error = Word('.' + alphanums) + COLON + SkipTo(lineEnd)
file_item = Keyword('File') + quotedString + COMMA + line + dig + COMMA + Keyword('in') + module + Word(printables)
bnf = SkipTo(start_trace) + (start_trace + OneOrMore(file_item) + error).setParseAction(trace_parse)
# bnf.setDebug(True)
bnf.parseString(trace_string)

