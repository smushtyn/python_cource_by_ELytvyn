import unittest
from messenger.main import MessageType
from messenger.user_status import UserStatus
from messenger.dbuser import DBUser


class TestDBUser(unittest.TestCase):

    def test_db_user(self):
        u = DBUser('nick1')
        u1 = DBUser('nick2')
        u1.status = UserStatus.ONLINE
        u.add_user(u1)
        for user in u.get_users():
            self.assertTrue(user.status == UserStatus.ONLINE)

    def test_status_to_string(self):
        self.assertEqual(UserStatus.to_string(1), 'ONLINE')
        self.assertEqual(UserStatus.to_string(4), 'UNKNOWN')
        self.assertEqual(MessageType.to_string(3), 'ADD_FRIEND')
        self.assertEqual(MessageType.to_string(5), 'UNKNOWN')
