import json
from collections import defaultdict
from messenger.dbuser import DBUserDict, DBUser
from messenger.user_status import UserStatus
from utils import Enum, JsonObject


class MessageStatus(object):
    SENT = 1
    RECEIVED = 2


class MessageType(Enum):
    UNKNOWN_TYPE = 0
    INIT = 1
    STATUS = 2
    MESSAGE = 3
    ADD_FRIEND = 4
    DEL_FRIEND = 5


class MessageProcessor(object):
    def __init__(self):
        self._connected_users = DBUserDict()
        self._msg_queue = MessageQueue()

    def process_message(self, message, conn_sender):
        """
        Processing messages
        :param message: Message
        :return:
        """
        nick = message.nickname
        msg_type = message.type

        # setdefault writes to dict pairs is they aren't there
        dbuser = self._connected_users.setdefault(nick, (DBUser(nick), conn_sender))

        if msg_type == MessageType.STATUS:
            statuses = [{'nickname': friend.nickname, 'status': friend.status} for friend in dbuser.get_users()]
            resp = {'nickname': nick,
                    'friend': statuses}
            resp_json = json.dumps(resp)
            conn_sender.send(resp_json)
        elif msg_type == MessageType.INIT:
            dbuser.status = message.status
            print "{} connected, status: {}".format(nick, UserStatus.to_string(dbuser.status))
        elif msg_type == MessageType.ADD_FRIEND:
            # {friend: nickname}
            # TODO: Except case with non-existent DBUser
            dbuser.status = message.status

            print "{} connected, status: {}".format(nick, UserStatus.to_string(dbuser.status))
        else:
            print "WARN: unknown message type"


class Message(JsonObject):
    """
    Message of next structure:
    {
        nickname: sender,
        recipient: recipient_nickname [optional],
        type: message_type

        =============
        some additional fields
        =============
     }
    """
    pass


class MessageQueue(object):

    def __init__(self):
        # {DBUser(): []}
        self._messages = defaultdict(set)

    def get_messages(self, user):
        return self._messages[user]

    def add_message(self, recipient, message):
        self._messages[recipient].add(message)