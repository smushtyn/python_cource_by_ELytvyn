from messenger.utils import Enum


class UserStatus(Enum):
    ONLINE = 1
    OFFLINE = 2
    BUSY = 3