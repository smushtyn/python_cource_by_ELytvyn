import json

d = {i: i**2 for i in xrange(10)}


class MyClass():

    # called if need to check whether smth is not None, false, 0 etc.
    def __nonzero__(self):
        # expression
        return bool(1)

# here are 2 calls to dict
if 5 in d: # search for key in dict by hash
    print d[5]

# advanced tip: one call to dict by key
try:
    print d[5]
except KeyError:
    pass

c = MyClass()
if c:
    print 'true'

# l = [2, 5, 6, 7, 5, 5, 5]
# print l
#
# for i in l:
#     if i == 5 and i % 5 == 0:
#         l.remove(i)
# print l

l = [2, 5, 6, 7, 5, 5, 5]

#idx = 0

# strategy pattern
def filter_n(iterable, filter_fn):
    idx = 0
    while idx < len(iterable):
        if filter_fn(iterable[idx]):
            del l[idx]
        else:
            idx += 1
    return iterable

l = filter_n(l, lambda x: not x % 5 and x % 10)
print l

# ======================================================

j = """{
        "name": "John",
        "surname": "Smith",
        "age": 30,
        "links": [
                {"link1": 5},
                {"link1": 10, "link2": 15},
                {"link1": 5}
        ]
    }"""


class Attribute(dict):
    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError:
            return None


a = Attribute()
a.update(json.loads(j))

#print a.name


def walk_json(json_data, key=None, indent=0):
    if isinstance(json_data, list):
        for item in json_data:
            walk_json(item, key=key, indent=indent + 1)
    elif isinstance(json_data, dict):
        for k, v in json_data.iteritems():
            walk_json(v, key=k, indent=indent + 1)
    else:
        ind = " " * indent * 4
        if key:
            print "{}{}: {}".format(ind, key, json_data)
        else:
            print json_data


walk_json(json.loads(j))
